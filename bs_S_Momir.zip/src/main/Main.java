package main;

import java.io.FileNotFoundException;

public class Main {//from here it starts

	public static void main(String[] args) throws FileNotFoundException {
		LaunchLogin launchPage = new LaunchLogin(); 

	}

}
