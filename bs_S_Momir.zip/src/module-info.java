module Bookshop {
	requires java.desktop;
}